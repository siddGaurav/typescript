# CRAETE TYPESCRIPT PROJECT COMMAND
1 npm init -y
2 npm install -D typescript
3 npm install -D tsx
4 npm install -D @types/node
5 npx tsc --init
6 npm install -D @types/express
7 npm install express
8 npm i -D @types/bcrypt
9 npm install bcrypt


