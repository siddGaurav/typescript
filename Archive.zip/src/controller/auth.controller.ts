import type { NextFunction, Request, Response } from "express";
import { genHash } from "../utils/utils.js";
import { User } from "../model/user.model.js";

export const signupAuth = async (req: Request, res: Response, next: NextFunction) => {
    const { name, email, phone, password } = req.body



    const dbres = await User.create({
        name: String(name),
        email: String(email),
        phone: String(phone),
        password: await genHash(password)

    });

    if(dbres){
        
    }

    res.json({
        status: "success"
    })
}