import type { Request, Response, NextFunction } from 'express';
import { Cart } from '../model/cart.model.js';
import { validationResult } from 'express-validator';
import { Product } from '../model/product.model.js';

export const addToCart = async (req: Request, res: Response, next: NextFunction) => {
    try {

        const errors = validationResult(req);
        if (!errors.isEmpty()) {
            const msgs = errors.array().map(e => e.msg);

            return res.status(400).json({ status: 'failed', message: msgs });
        }
        const { user_id, product_id, product_qty } = req.body;

        let existingItem: any = await Cart.findOne({ where: { user_id, product_id }, raw: true });

        if (existingItem) {
            // existingItem.product_qty += product_qty;
            console.log(existingItem)
            await Cart.update(
                { product_qty: existingItem.product_qty + 1 },
                { where: { id: existingItem.id } }
            );

        }
        else {
            existingItem = await Cart.create({ user_id, product_id, product_qty });
        }


        const newItem = await Cart.findByPk(existingItem.id);
        res.status(201).json({ status: 'success', message: 'Item added to cart', data: newItem });
    } catch (err) {
        next(err);
    }
};


export const getCartItems = async (
    req: Request,
    res: Response
) => {
    try {
        const userId = req.params?.user_id;

        if (!userId) {
            return res
                .status(400)
                .json({ success: false, message: "User ID is required" });

        }

        // Check if user exists
        // // const user = await User.findByPk(userId);
        // if (!user) {
        //     res.status(404).json({ success: false, message: "User not found" });
        //     return;
        // }

        //const user_Id = parseInt(userId, 10);

        const cartItems = await Cart.findAll({
            where: { user_id: userId },
            include: [{ model: Product, as: "product" }], raw: true

        });

        // Calculate cart total
        // let cartTotal = 0;
        // const itemsWithTotal = cartItems.map((item: any) => {
        //     const itemTotal = Number(item.product.productPrice) * item.quantity;
        //     cartTotal += itemTotal;
        //     return {
        //         ...item.dataValues,
        //         totalPrice: itemTotal,
        //     };
        // });

        res.status(200).json({
            success: true,
            message: "Cart items retrieved successfully",
            data: {
                items: cartItems,
                itemCount: cartItems.length,
            },
        });
    } catch (error) {
        console.error("Error fetching cart items:", error);
        res.status(500).json({
            success: false,
            message: "Internal server error",
            error: error instanceof Error ? error.message : "Unknown error",
        });
    }
};