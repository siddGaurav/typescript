import { body, type ValidationChain } from "express-validator";

export const createProductValidation: ValidationChain[] = [
    body('product_name')
        .trim()
        .notEmpty().withMessage('Product name is required')
        .isLength({ min: 2 }).withMessage('Product name must be at least 2 characters'),
    body('product_price')
        .notEmpty().withMessage('Product price is required')
        .isFloat({ gt: 0 }).withMessage('Product price must be a number greater than 0'),
    body('product_desc')
        .optional()
        .isLength({ max: 2000 }).withMessage('Description is too long'),
    body('product_sku')
        .optional()
        .isAlphanumeric().withMessage('SKU must be alphanumeric'),
    body('product_unit').notEmpty().withMessage("Unit is Required"),
    body('cat_id')
        .notEmpty().withMessage('Category ID is required')
        .isInt({ gt: 0 }).withMessage('Category ID must be a positive integer'),
];

export const updateProductValidation: ValidationChain[] = [
    body('product_name')
        .trim()
        .notEmpty().withMessage('Product name is required')
        .isLength({ min: 2 }).withMessage('Product name must be at least 2 characters'),
    body('product_price')
        .notEmpty().withMessage('Product price is required')
        .isFloat({ gt: 0 }).withMessage('Product price must be a number greater than 0'),
    body('product_desc')
        .optional()
        .isLength({ max: 2000 }).withMessage('Description is too long'),
    body('product_sku')
        .optional()
        .isAlphanumeric().withMessage('SKU must be alphanumeric'),
    body('product_unit').notEmpty().withMessage("Unit is Required"),
    body('cat_id')
        .notEmpty().withMessage('Category ID is required')
        .isInt({ gt: 0 }).withMessage('Category ID must be a positive integer'),
];


export const createCategoryValidation: ValidationChain[] = [
    body('cat_name')
        .trim()
        .notEmpty().withMessage('Category name is required')
        .isLength({ min: 2 }).withMessage('Category name must be at least 2 characters'),
    body('cat_desc')
        .trim()
        .notEmpty().withMessage('Category description is required')
        .isLength({ min: 5 }).withMessage('Category description must be at least 5 characters'),
    body('cat_slug')
        .trim()
        .notEmpty().withMessage('Category slug is required')
        .isSlug().withMessage('Category slug must be a valid slug'),
];

export const updateCategoryValidation: ValidationChain[] = [
    body('cat_name')
        .trim()
        .notEmpty().withMessage('Category name is required')
        .isLength({ min: 2 }).withMessage('Category name must be at least 2 characters'),
    body('cat_desc')
        .trim()
        .notEmpty().withMessage('Category description is required')
        .isLength({ min: 5 }).withMessage('Category description must be at least 5 characters'),
    body('cat_slug')
        .trim()
        .notEmpty().withMessage('Category slug is required')
        .isSlug().withMessage('Category slug must be a valid slug'),
];

export const createCartValidation: ValidationChain[] = [
    body('user_id')
        .notEmpty().withMessage('User ID is required')
        .isInt({ gt: 0 }).withMessage('User ID must be a positive integer'),
    body('product_id')
        .notEmpty().withMessage('Product ID is required')
        .isInt({ gt: 0 }).withMessage('Product ID must be a positive integer'),
    body('product_qty')
        .notEmpty().withMessage('Product quantity is required')
        .isInt({ gt: 0 }).withMessage('Product quantity must be a positive integer'),
];

export const updateCartValidation: ValidationChain[] = [
    body('product_qty')
        .notEmpty().withMessage('Product quantity is required')
        .isInt({ gt: 0 }).withMessage('Product quantity must be a positive integer'),
];








