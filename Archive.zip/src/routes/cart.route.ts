import express from "express";
import *  as CartController from "../controller/cart.controller.js";
import { createCartValidation } from "../middleware/validators.js";

const cartRouter = express.Router();

cartRouter.post("/", createCartValidation, CartController.addToCart);
cartRouter.get("/:user_id", CartController.getCartItems);
// cartRouter.put("/:product_id", CartController.updateCartItem);
// cartRouter.delete("/:product_id", CartController.removeFromCart);

export default cartRouter;