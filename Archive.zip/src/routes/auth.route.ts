import Express from 'express'
import * as authController from '../controller/auth.controller.js';


const authRouter = Express.Router();

authRouter.get("/signup", authController.signupAuth);

export default authRouter;