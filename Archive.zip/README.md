# typescript

git remote add origin https://github.com/siddGaurav/typescript.git
git branch -M main
git push -u origin main


echo "# typescript" >> README.md
git init
git add README.md
git commit -m "first commit"
git branch -M main
git remote add origin https://github.com/siddGaurav/typescript.git
git push -u origin main